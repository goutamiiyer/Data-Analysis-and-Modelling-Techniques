Name		: Goutami Padmanabhan
UTA ID		: 1001669338
Language Used	: Java

Compilation and Run instructions: Please type the commands given below in the command line.

For Compilation:
javac simulateDist.java

Some Run examples:
java simulateDist 5 bernoulli 0.3
java simulateDist 5 binomial 10 0.3
java simulateDist 5 geometric 0.3
java simulateDist 5 neg-binomial 10 0.3
java simulateDist 5 poisson 20
java simulateDist 5 arb-discrete 0.2 0.5 0.8 0.7 0.65
java simulateDist 5 uniform 0.5 0.8
java simulateDist 5 exponential 0.4
java simulateDist 5 gamma 0.5 0.8
java simulateDist 5 normal 0.6 0.2


The seed value is given as below. Please change the value in the code as required.
static long seed = 8;
The program execution starts from the main function in line 6
